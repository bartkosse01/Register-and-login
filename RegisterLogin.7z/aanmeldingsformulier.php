aanmeldingsformulier

<?php
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utg-8" />
        <link rel="stylesheet" type="text/css"  href="css/css.css">
    </head>
    <body>
    <form action=
        <div id=main-container>
                <h1>Continue to register</h1>
                <div id="inputfieldsdiv">
                <input type="first name" placeholder="enter first name" name="first name"> 
                <br>
                <input type="last name" placeholder="enter last name" name="last name"> 
                <br>
                <input type="email" placeholder="enter e-mail adress" name="e-mailadress">
                <br>
                <input type="username" placeholder="enter username" name="username"> 
                <br>
                <input type="password" placeholder="enter password" name="password">
                <br>
                <input type="password" placeholder="confirm password" name="confirm password">
                <br>
                </div>
                <div id="buttonchoicediv">
                    <button type="submit" name="submit" id="confirmbutton">Sign up</button>
                </div>
        </div>
    </body>
</html>