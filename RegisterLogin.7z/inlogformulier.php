<!DOCTYPE html>
<html>
    <head>
        <meta charset="utg-8" />
        <link rel="stylesheet" type="text/css"  href="css/css.css">
        <?php
        session_start();
            if (isset($_SESSION['message']))
            {
                echo "<script> alert('succesfully registerd');</script>";
            }
        ?>
    </head>
    <body>
        <div id=main-container>
                <h1>Continue to login</h1>
                <form action="" method = "POST">
                <div id="aanmelddiv">
                    <input type="username" placeholder="Enter username" name="username">
                </div>
                <div id="inlogdiv">
                    <input type="password" placeholder="Enter password" name="password">
                </div>
                <input type="submit" name="login_btn" value="Register" />
                </form>
        </div>
    </body>
</html>