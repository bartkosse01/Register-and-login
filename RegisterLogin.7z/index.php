<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utg-8" />
        <link rel="stylesheet" type="text/css"  href="css/css.css">
    </head>
    <body>
        <div id="main-container">
            <?php
            if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
            {
                // already loggedin...
                ?>
                <h3>Welkom!!</h3>
                <?php
            }
            else
            {
                ?>


                <h1>What do you want?</h1>
                <div id="aanmelddiv">
                <ul>
                    <li><a href="register.php">register</a></li>
                </div>
                <div id="inlogdiv">
                    <li><a href="inlogformulier.php">log in</a></li>
                </div>
            </ul>
            <?php
            }
            ?>
    </body>
</html>