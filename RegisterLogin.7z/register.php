
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css"  href="css/css.css">
    <?php
    session_start();


    if(!isset($_SESSION['loggedin']))
    {
        $_SESSION['loggedin'] = false;
    }

    // connect to database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "register_and_login";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $database);

    // Check connection
    if (!$conn) 
    {
        die("Connection failed: " . mysqli_connect_error());
    }

    if (isset($_POST['register_btn']))
    {
        $firstname   = $_POST['firstname'];
        $lastname   = $_POST['lastname']; 
        $username   = $_POST['username'];
        $email      = $_POST['email'];
        $password	 = $_POST['password'];
        $password2   = $_POST['password2'];

        if ($password == $password2) {
            // create user
            $password = md5($password);
            $sql = "INSERT INTO `users`(`userId`, `username`, `firstname`, `lastname`, `email`, `password`) VALUES (null, '$username', '$firstname', '$lastname', '$email', '$password')";

            // die($sql);

            mysqli_query($conn, $sql);
            $_SESSION['message'] = "You are now logged in";
            $_SESSION['username'] = $username;
            header("location: inlogformulier.php"); //redirect to login page
        }
        else{
            //failed
        }
    }
?>
</head>
<body>
<div id="maindiv">
    <div class="header">
        <h1>Continue to register</h1>
    </div>
<form method="post" action="register.php"> 
    <table>
        <tr>
            <td>First name:</td>
            <td><input type="text" name="firstname" class="textInput" required></td>
        </tr>
        <tr>
            <td>Last name:</td>
            <td><input type="text" name="lastname" class="textInput" required></td>
        </tr>
        <tr>
            <td>Username:</td>
            <td><input type="text" name="username" class="textInput" required></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="email" name="email" class="textInput" required></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" name="password" class="textInput" required></td>
        </tr>
        <tr>
            <td>Confirm Password:</td>
            <td><input type="password" name="password2" class="textInput" required></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="register_btn" value="Register" required></td>
        </tr>
    </table>
</form>
</div>
</body>
</html>